#include "confirm.h"

int confirm(int input){
    while(input){
        int tmp = input % 10;
        if(tmp == 1 || tmp == 4 || tmp == 7) return 1;
        input = input / 10;
    }

    return 0;
}
