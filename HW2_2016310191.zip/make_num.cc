#include "make_num.h"
#include <iostream>

int make_largest_num(int input){
    while(confirm(input)){
        input++;
    }

    return input;
}

int make_smallest_num(int input){
    while(confirm(input)){
        input--;
    }

    return input;
}
