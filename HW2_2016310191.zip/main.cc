#include <iostream>
#include "confirm.h"
#include "make_num.h"
using namespace std;

int main(int argc, char* argv[]){
    int input = atoi(argv[1]);
   
    int flag = confirm(input);// confirm if there is 1 or 4 or 7 number;
    
    if(flag == 0){
        cout << input;
    }// if there's no 1, 4, or 7, print out a;
    else{
        cout << make_smallest_num(input) << " " << make_largest_num(input);
    }// else, print out the next largest number and next smallest number;

    return 0;
}
