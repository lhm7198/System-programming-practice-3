int confirm(int input);
