#include "confirm.h"

int make_largest_num(int input);
int make_smallest_num(int input);
